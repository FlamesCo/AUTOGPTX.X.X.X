import psutil

def get_system_usage():
    '''
    Returns the CPU, memory, and disk usage of the system.
    '''
    cpu_usage = psutil.cpu_percent()
    memory_usage = psutil.virtual_memory().percent
    disk_usage = psutil.disk_usage('/').percent
    return f'CPU usage: {cpu_usage}%\nMemory usage: {memory_usage}%\nDisk usage: {disk_usage}%'