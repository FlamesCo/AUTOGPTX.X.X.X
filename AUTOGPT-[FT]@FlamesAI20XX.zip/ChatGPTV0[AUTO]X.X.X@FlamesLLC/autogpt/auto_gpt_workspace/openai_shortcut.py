import webbrowser
webbrowser.open('https://openai.com/')