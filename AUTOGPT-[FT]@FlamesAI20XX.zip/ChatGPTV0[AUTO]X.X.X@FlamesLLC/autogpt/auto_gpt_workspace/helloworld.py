# This is a basic Python 'Hello, World!' program.
print('Hello, World!')